package com.example.photostudio;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.util.List;

public class ReferencePhotoActivity extends AppCompatActivity {

    Button btnPrev, btnNext;
    RadioGroup radioGroupCategory;
    RadioButton radioSelfPhoto, radioFamilyPhoto, radioGroupPhoto, radioEventPhoto, radioOthersPhoto;
    PhotoView photo;
    int curNum = 0;
    File[] imageFiles = new File[0];
    String imageFname;
    TextView tvCur;

    private static final int PERMISSION_REQUEST_CODE = 1;
    private FirebaseStorage storage;
    private StorageReference storageReference;
    private String studioId; // 스튜디오 ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reference_photo);

        // 인텐트에서 스튜디오 ID를 가져옴
        studioId = getIntent().getStringExtra("studioId");

        // 권한이 없는 경우
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // 권한 요청
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }

        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReferenceFromUrl("gs://photostudio-815cd.appspot.com");

        radioGroupCategory = findViewById(R.id.radioGroupCategory);
        radioSelfPhoto = findViewById(R.id.radioSelfPhoto);
        radioFamilyPhoto = findViewById(R.id.radioFamilyPhoto);
        radioGroupPhoto = findViewById(R.id.radioGroupPhoto);
        radioEventPhoto = findViewById(R.id.radioEventPhoto);
        radioOthersPhoto = findViewById(R.id.radioOthersPhoto);

        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        photo = findViewById(R.id.photoView);
        tvCur = findViewById(R.id.tvCur);

        btnPrev.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (imageFiles.length == 0) return;
                if (curNum <= 0) {
                    curNum = imageFiles.length - 1;
                } else {
                    curNum--;
                }
                updateImage();
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (imageFiles.length == 0) return;
                if (curNum >= imageFiles.length - 1) {
                    curNum = 0;
                } else {
                    curNum++;
                }
                updateImage();
            }
        });

        radioGroupCategory.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioSelfPhoto) {
                    loadImages("SelfPhoto");
                } else if (checkedId == R.id.radioFamilyPhoto) {
                    loadImages("FamilyPhoto");
                } else if (checkedId == R.id.radioGroupPhoto) {
                    loadImages("GroupPhoto");
                } else if (checkedId == R.id.radioEventPhoto) {
                    loadImages("EventPhoto");
                } else if (checkedId == R.id.radioOthersPhoto) {
                    loadImages("OthersPhoto");
                }
            }
        });
    }


    private void loadImages(String category) {
        String categoryPath = studioId + "/" + category; // studioId를 포함한 경로 생성
        StorageReference categoryRef = storageReference.child(categoryPath);
        categoryRef.listAll()
                .addOnSuccessListener(listResult -> {
                    int totalItems = listResult.getItems().size();
                    if (totalItems == 0) {
                        Log.e("파일 오류", "해당 카테고리에 이미지가 없습니다.");
                        clearImages();
                        return;
                    }

                    imageFiles = new File[totalItems];
                    downloadImages(listResult.getItems());
                })
                .addOnFailureListener(e -> {
                    Log.e("파일 오류", "이미지 목록 불러오기 실패: " + e.getMessage());
                    clearImages();
                });
    }


    private void downloadImages(List<StorageReference> items) {
        for (int i = 0; i < items.size(); i++) {
            final int index = i;
            StorageReference itemRef = items.get(index);

            try {
                File localFile = File.createTempFile("images", "jpg");
                itemRef.getFile(localFile)
                        .addOnSuccessListener(taskSnapshot -> {
                            imageFiles[index] = localFile;
                            if (allImagesDownloaded()) {
                                curNum = 0; // 첫 번째 이미지로 리셋
                                updateImage();
                            }
                        })
                        .addOnFailureListener(exception -> Log.e("파일 오류", "이미지 다운로드 실패: " + exception.getMessage()));
            } catch (Exception e) {
                Log.e("파일 오류", "임시 파일 생성 실패: " + e.getMessage());
            }
        }
    }



    private boolean allImagesDownloaded() {
        for (File file : imageFiles) {
            if (file == null) return false; // 아직 다운로드되지 않은 파일이 있음
        }
        return true; // 모든 이미지가 다운로드됨
    }


    private void clearImages() {
        imageFiles = new File[0];
        updateImage();
    }


    private void updateImage() {
        if (imageFiles.length > 0) {
            imageFname = imageFiles[curNum].toString();
            photo.imagePath = imageFname;
            photo.invalidate();
            tvCur.setText((curNum + 1) + "/" + imageFiles.length);
        } else {
            photo.imagePath = null;
            photo.invalidate();
            tvCur.setText("0/0");
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("권한 요청", "권한이 부여되었습니다.");
                radioSelfPhoto.setChecked(true); // 권한 부여된 후 SelfPhoto 라디오 버튼 체크
                loadImages("SelfPhoto"); // SelfPhoto 이미지 로드
            } else {
                Log.d("권한 요청", "권한이 거부되었습니다.");
            }
        }
    }



}
