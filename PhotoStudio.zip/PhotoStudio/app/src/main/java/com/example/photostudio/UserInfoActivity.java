package com.example.photostudio;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;

public class UserInfoActivity extends AppCompatActivity {

    private static final String TAG = "UserInfoActivity";
    private TextView textCustomerId;
    private TextView textPassword;
    private TextView textStudio;
    private EditText editName;
    private EditText editAge;
    private EditText editPhone;
    private EditText editEmail;
    private Button buttonSave;
    private FirebaseFirestore db;
    private String customerId;
    private String studioId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_info);

        textCustomerId = findViewById(R.id.text_customer_id);
        textPassword = findViewById(R.id.text_password);
        textStudio = findViewById(R.id.text_studio);
        editName = findViewById(R.id.edit_name);
        editAge = findViewById(R.id.edit_age);
        editPhone = findViewById(R.id.edit_phone);
        editEmail = findViewById(R.id.edit_email);
        buttonSave = findViewById(R.id.button_save);

        // Firestore 인스턴스 초기화
        db = FirebaseFirestore.getInstance();

        // 인텐트로부터 고객 아이디와 사진관 아이디를 가져옴
        customerId = getIntent().getStringExtra("customerId");
        studioId = getIntent().getStringExtra("studioId");

        if (customerId != null) {
            loadUserInfo();
        } else {
            Toast.makeText(this, "고객 ID를 가져올 수 없습니다.", Toast.LENGTH_SHORT).show();
            finish();
        }

        // 저장 버튼 클릭 시 사용자 정보 저장
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUserInfo();
            }
        });
    }

    // 사용자 정보를 Firestore에서 로드
    private void loadUserInfo() {
        DocumentReference docRef = db.collection("customers").document(customerId);
        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if (documentSnapshot.exists()) {
                    String customerId = documentSnapshot.getString("customerId");
                    String password = documentSnapshot.getString("password");
                    String name = documentSnapshot.getString("name");
                    String age = documentSnapshot.getString("age");
                    String phone = documentSnapshot.getString("phone");
                    String email = documentSnapshot.getString("email");

                    textCustomerId.setText(customerId != null ? customerId : "N/A");
                    textPassword.setText(password != null ? password : "N/A");
                    textStudio.setText(studioId != null ? studioId : "없음");
                    editName.setText(name != null ? name : "");
                    editAge.setText(age != null ? age : ""); // String으로 설정
                    editPhone.setText(phone != null ? phone : "");
                    editEmail.setText(email != null ? email : "");
                    Log.d(TAG, "사용자 정보를 성공적으로 가져왔습니다.");
                } else {
                    Toast.makeText(UserInfoActivity.this, "사용자 정보를 가져올 수 없습니다.", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "사용자 정보가 존재하지 않습니다.");
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(UserInfoActivity.this, "사용자 정보를 가져오는데 실패했습니다.", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "사용자 정보를 가져오는데 실패했습니다.", e);
            }
        });
    }

    // 사용자 정보를 Firestore에 저장
    private void saveUserInfo() {
        String name = editName.getText().toString();
        String age = editAge.getText().toString(); // String으로 가져옴
        String phone = editPhone.getText().toString();
        String email = editEmail.getText().toString();

        if (name.isEmpty() || age.isEmpty() || phone.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "모든 필드를 입력해 주세요.", Toast.LENGTH_SHORT).show();
            Log.w(TAG, "필드가 비어 있습니다.");
            return;
        }

        DocumentReference docRef = db.collection("customers").document(customerId);
        docRef.update("name", name, "age", age, "phone", phone, "email", email) // String으로 업데이트
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(UserInfoActivity.this, "정보가 저장되었습니다.", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "사용자 정보가 성공적으로 저장되었습니다.");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(UserInfoActivity.this, "정보 저장에 실패했습니다.", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "사용자 정보 저장에 실패했습니다.", e);
                    }
                });
    }
}
