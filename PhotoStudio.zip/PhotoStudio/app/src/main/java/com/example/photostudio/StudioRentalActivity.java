package com.example.photostudio;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;

public class StudioRentalActivity extends AppCompatActivity {

    private static final String TAG = "StudioRentalActivity";
    private EditText editTextDate;
    private EditText editTextStartTime;
    private EditText editTextEndTime;
    private Button buttonRentStudio;
    private TextView textSelectedStudio;
    private ImageView imageView;
    private Button buttonPreviousImage;
    private Button buttonNextImage;

    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private StorageReference storageReference;

    private String customerId;
    private String studioId;
    private String studioName;
    private String selectedDate;
    private String selectedStartTime;
    private String selectedEndTime;

    private List<StorageReference> imageReferences = new ArrayList<>();
    private int currentImageIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.studio_rental);

        editTextDate = findViewById(R.id.editTextDate);
        editTextStartTime = findViewById(R.id.editTextStartTime);
        editTextEndTime = findViewById(R.id.editTextEndTime);
        buttonRentStudio = findViewById(R.id.buttonRentStudio);
        textSelectedStudio = findViewById(R.id.textSelectedStudio);
        imageView = findViewById(R.id.imageView);
        buttonPreviousImage = findViewById(R.id.buttonPreviousImage);
        buttonNextImage = findViewById(R.id.buttonNextImage);

        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReferenceFromUrl("gs://photostudio-815cd.appspot.com");

        customerId = getIntent().getStringExtra("customerId");
        studioId = getIntent().getStringExtra("studioId");

        if (studioId == null || customerId == null) {
            Toast.makeText(this, "스튜디오 또는 고객 정보를 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadStudioName();
        loadImages();

        editTextDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        editTextStartTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog(true);
            }
        });

        editTextEndTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog(false);
            }
        });

        buttonRentStudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmBooking();
            }
        });

        buttonPreviousImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPreviousImage();
            }
        });

        buttonNextImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showNextImage();
            }
        });
    }

    private void loadStudioName() {
        db.collection("studios").document(studioId).get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            studioName = documentSnapshot.getString("name");
                            textSelectedStudio.setText("선택된 사진관: " + studioName);
                        } else {
                            Toast.makeText(StudioRentalActivity.this, "스튜디오 정보를 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(StudioRentalActivity.this, "스튜디오 정보를 불러오는데 실패했습니다.", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "스튜디오 정보를 불러오는데 실패했습니다.", e);
                        finish();
                    }
                });
    }

    private void loadImages() {
        storageReference.child(studioId + "/StudioInterior").listAll()
                .addOnSuccessListener(new OnSuccessListener<ListResult>() {
                    @Override
                    public void onSuccess(ListResult listResult) {
                        for (StorageReference item : listResult.getItems()) {
                            imageReferences.add(item);
                        }
                        if (!imageReferences.isEmpty()) {
                            showImage(0);
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(StudioRentalActivity.this, "이미지를 불러오는데 실패했습니다.", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "이미지를 불러오는데 실패했습니다.", e);
                    }
                });
    }

    private void showImage(int index) {
        if (index >= 0 && index < imageReferences.size()) {
            StorageReference imageRef = imageReferences.get(index);
            imageRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    Glide.with(StudioRentalActivity.this)
                            .load(uri)
                            .into(imageView);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(StudioRentalActivity.this, "이미지를 불러오는데 실패했습니다.", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "이미지를 불러오는데 실패했습니다.", e);
                }
            });
        }
    }

    private void showPreviousImage() {
        if (imageReferences.isEmpty()) return;
        currentImageIndex = (currentImageIndex - 1 + imageReferences.size()) % imageReferences.size();
        showImage(currentImageIndex);
    }

    private void showNextImage() {
        if (imageReferences.isEmpty()) return;
        currentImageIndex = (currentImageIndex + 1) % imageReferences.size();
        showImage(currentImageIndex);
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    String dayOfWeek = getDayOfWeek(year, month, dayOfMonth);
                    selectedDate = String.format(Locale.getDefault(), "%d년 %d월 %d일(%s)", year, month + 1, dayOfMonth, dayOfWeek);
                    editTextDate.setText(selectedDate);
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void showTimePickerDialog(boolean isStartTime) {
        View dialogView = View.inflate(this, R.layout.time_picker_dialog, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);

        NumberPicker numberPickerHour = dialogView.findViewById(R.id.numberPickerHour);
        NumberPicker numberPickerMinute = dialogView.findViewById(R.id.numberPickerMinute);

        numberPickerHour.setMinValue(0);
        numberPickerHour.setMaxValue(23);
        numberPickerHour.setWrapSelectorWheel(true);

        numberPickerMinute.setDisplayedValues(new String[]{"00", "30"});
        numberPickerMinute.setMinValue(0);
        numberPickerMinute.setMaxValue(1);
        numberPickerMinute.setWrapSelectorWheel(true);

        builder.setPositiveButton("확인", (dialog, which) -> {
            int hour = numberPickerHour.getValue();
            int minute = numberPickerMinute.getValue() * 30; // 00 또는 30
            String time = String.format(Locale.getDefault(), "%02d:%02d", hour, minute);
            if (isStartTime) {
                selectedStartTime = time;
                editTextStartTime.setText(time);
            } else {
                selectedEndTime = time;
                editTextEndTime.setText(time);
            }
        });
        builder.setNegativeButton("취소", null);
        builder.show();
    }

    private void confirmBooking() {
        if (selectedDate == null || selectedStartTime == null || selectedEndTime == null) {
            Toast.makeText(this, "날짜와 시간을 선택해 주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        // 시작 시간과 종료 시간을 24시간 형식으로 변환하여 비교
        try {
            int startHour = convertTo24Hour(selectedStartTime);
            int endHour = convertTo24Hour(selectedEndTime);

            if (endHour <= startHour) {
                Toast.makeText(this, "종료 시간은 시작 시간보다 이후여야 합니다.", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            Toast.makeText(this, "시간 파싱에 실패했습니다.", Toast.LENGTH_SHORT).show();
            return;
        }

        // 선택된 예약 시간을 "yyyy년 MM월 dd일(요일) HH:mm ~ HH:mm" 형식으로 저장
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일(EEE) HH:mm", Locale.getDefault());
        String formattedBookDate = selectedDate + String.format(Locale.getDefault(), " %s ~ %s", selectedStartTime, selectedEndTime);

        // 이미 예약된 시간인지 확인
        db.collection("books")
                .whereEqualTo("studioId", studioId)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<String> bookedTimeSlots = new ArrayList<>();
                        for (DocumentSnapshot document : task.getResult()) {
                            String bookedDate = document.getString("bookDate");

                            if (bookedDate != null && bookedDate.startsWith(selectedDate)) {
                                String[] parts = bookedDate.split(" ");
                                String startTime = parts[3];
                                String endTime = parts[5];

                                // 시작 시간과 종료 시간을 30분 단위로 나누어 bookedTimeSlots에 추가
                                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
                                try {
                                    Date start = timeFormat.parse(startTime);
                                    Date end = timeFormat.parse(endTime);
                                    Calendar startCal = Calendar.getInstance();
                                    startCal.setTime(start);

                                    while (startCal.getTime().before(end)) {
                                        bookedTimeSlots.add(timeFormat.format(startCal.getTime()));
                                        startCal.add(Calendar.MINUTE, 30);
                                    }
                                } catch (Exception e) {
                                    Log.e(TAG, "시간 파싱 오류: " + e.getMessage());
                                }
                            }
                        }

                        // 예약 시간대와 기존 예약 시간대가 겹치는지 확인
                        List<String> requestedTimeSlots = new ArrayList<>();
                        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
                        try {
                            Date start = timeFormat.parse(selectedStartTime);
                            Date end = timeFormat.parse(selectedEndTime);
                            Calendar startCal = Calendar.getInstance();
                            startCal.setTime(start);

                            while (startCal.getTime().before(end)) {
                                requestedTimeSlots.add(timeFormat.format(startCal.getTime()));
                                startCal.add(Calendar.MINUTE, 30);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "시간 파싱 오류: " + e.getMessage());
                        }

                        for (String slot : requestedTimeSlots) {
                            if (bookedTimeSlots.contains(slot)) {
                                Toast.makeText(StudioRentalActivity.this, "이미 예약된 시간입니다. 전체 일정을 확인해주세요.", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        }

                        // 예약이 중복되지 않았으므로 예약 진행
                        String bookDetails = String.format(Locale.getDefault(), "날짜: %s\n시간: %s ~ %s", selectedDate, selectedStartTime, selectedEndTime);

                        new AlertDialog.Builder(this)
                                .setTitle("스튜디오 대여")
                                .setMessage(bookDetails)
                                .setPositiveButton("확인", (dialog, which) -> {
                                    rentStudio(formattedBookDate);
                                })
                                .setNegativeButton("취소", null)
                                .show();
                    } else {
                        Log.e(TAG, "Error getting documents: ", task.getException());
                        Toast.makeText(StudioRentalActivity.this, "예약 확인 중 오류가 발생했습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private int convertTo24Hour(String time) throws ParseException {
        SimpleDateFormat sdf24 = new SimpleDateFormat("HH:mm", Locale.KOREA);
        Date date = sdf24.parse(time);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.HOUR_OF_DAY);
    }

    private void rentStudio(String bookDate) {
        String bookId = db.collection("books").document().getId();
        Timestamp bookTimestamp = Timestamp.now();

        Map<String, Object> rental = new HashMap<>();
        rental.put("bookDate", bookDate);
        rental.put("bookId", bookId);
        rental.put("bookPurpose", "사진관 대여");
        rental.put("bookTimestamp", bookTimestamp);
        rental.put("customerId", customerId);
        rental.put("studioId", studioId);

        db.collection("books")
                .document(bookId)
                .set(rental)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(StudioRentalActivity.this, "예약되었습니다.", Toast.LENGTH_SHORT).show();
                        Toast.makeText(StudioRentalActivity.this, "예약 조회에서 확인 가능합니다.", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.e(TAG, "사진관 대여에 실패했습니다.", e);
                        Toast.makeText(StudioRentalActivity.this, "사진관 대여에 실패했습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private String getDayOfWeek(int year, int month, int dayOfMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, dayOfMonth);
        Date date = calendar.getTime();
        return new SimpleDateFormat("EEE", Locale.getDefault()).format(date);
    }
}
