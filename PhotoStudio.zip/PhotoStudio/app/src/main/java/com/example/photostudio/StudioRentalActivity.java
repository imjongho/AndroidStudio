package com.example.photostudio;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.Transaction;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;

public class StudioRentalActivity extends AppCompatActivity {

    private static final String TAG = "StudioRentalActivity";
    private EditText editTextDate;
    private EditText editTextStartTime;
    private EditText editTextEndTime;
    private Button buttonRentStudio;
    private TextView textSelectedStudio;
    private ImageView imageView;
    private Button buttonPreviousImage;
    private Button buttonNextImage;

    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private StorageReference storageReference;

    private String customerId;
    private String studioId;
    private String studioName;
    private String selectedDate;
    private String selectedStartTime;
    private String selectedEndTime;

    private List<StorageReference> imageReferences = new ArrayList<>();
    private int currentImageIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.studio_rental);

        editTextDate = findViewById(R.id.editTextDate);
        editTextStartTime = findViewById(R.id.editTextStartTime);
        editTextEndTime = findViewById(R.id.editTextEndTime);
        buttonRentStudio = findViewById(R.id.buttonRentStudio);
        textSelectedStudio = findViewById(R.id.textSelectedStudio);
        imageView = findViewById(R.id.imageView);
        buttonPreviousImage = findViewById(R.id.buttonPreviousImage);
        buttonNextImage = findViewById(R.id.buttonNextImage);

        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReferenceFromUrl("gs://photostudio-815cd.appspot.com");

        customerId = getIntent().getStringExtra("customerId");
        studioId = getIntent().getStringExtra("studioId");

        if (studioId == null || customerId == null) {
            Toast.makeText(this, "스튜디오 또는 고객 정보를 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadStudioName();
        loadImages();

        editTextDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        editTextStartTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog(true);
            }
        });

        editTextEndTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog(false);
            }
        });

        buttonRentStudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmBooking();
            }
        });

        buttonPreviousImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPreviousImage();
            }
        });

        buttonNextImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showNextImage();
            }
        });
    }

    // 스튜디오 이름을 불러오는 메서드
    private void loadStudioName() {
        db.collection("studios").document(studioId).get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            studioName = documentSnapshot.getString("name");
                            textSelectedStudio.setText("선택된 사진관: " + studioName);
                        } else {
                            Toast.makeText(StudioRentalActivity.this, "스튜디오 정보를 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(StudioRentalActivity.this, "스튜디오 정보를 불러오는데 실패했습니다.", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "스튜디오 정보를 불러오는데 실패했습니다.", e);
                        finish();
                    }
                });
    }

    // 스튜디오 이미지를 불러오는 메서드
    private void loadImages() {
        storageReference.child(studioId + "/StudioInterior").listAll()
                .addOnSuccessListener(new OnSuccessListener<ListResult>() {
                    @Override
                    public void onSuccess(ListResult listResult) {
                        for (StorageReference item : listResult.getItems()) {
                            imageReferences.add(item);
                        }
                        if (!imageReferences.isEmpty()) {
                            showImage(0);
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(StudioRentalActivity.this, "이미지를 불러오는데 실패했습니다.", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "이미지를 불러오는데 실패했습니다.", e);
                    }
                });
    }

    // 이미지를 보여주는 메서드
    private void showImage(int index) {
        if (index >= 0 && index < imageReferences.size()) {
            StorageReference imageRef = imageReferences.get(index);
            imageRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    Glide.with(StudioRentalActivity.this)
                            .load(uri)
                            .into(imageView);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(StudioRentalActivity.this, "이미지를 불러오는데 실패했습니다.", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "이미지를 불러오는데 실패했습니다.", e);
                }
            });
        }
    }

    // 이전 이미지를 보여주는 메서드
    private void showPreviousImage() {
        if (imageReferences.isEmpty()) return;
        currentImageIndex = (currentImageIndex - 1 + imageReferences.size()) % imageReferences.size();
        showImage(currentImageIndex);
    }

    // 다음 이미지를 보여주는 메서드
    private void showNextImage() {
        if (imageReferences.isEmpty()) return;
        currentImageIndex = (currentImageIndex + 1) % imageReferences.size();
        showImage(currentImageIndex);
    }

    // 날짜 선택 다이얼로그를 보여주는 메서드
    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    String dayOfWeek = getDayOfWeek(year, month, dayOfMonth);
                    selectedDate = String.format(Locale.getDefault(), "%d년 %d월 %d일(%s)", year, month + 1, dayOfMonth, dayOfWeek);
                    editTextDate.setText(selectedDate);
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    // 시간 선택 다이얼로그를 보여주는 메서드
    private void showTimePickerDialog(boolean isStartTime) {
        View dialogView = View.inflate(this, R.layout.time_picker_dialog, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);

        NumberPicker numberPickerHour = dialogView.findViewById(R.id.numberPickerHour);
        NumberPicker numberPickerMinute = dialogView.findViewById(R.id.numberPickerMinute);

        numberPickerHour.setMinValue(0);
        numberPickerHour.setMaxValue(23);
        numberPickerHour.setWrapSelectorWheel(true);

        numberPickerMinute.setDisplayedValues(new String[]{"00", "30"});
        numberPickerMinute.setMinValue(0);
        numberPickerMinute.setMaxValue(1);
        numberPickerMinute.setWrapSelectorWheel(true);

        builder.setPositiveButton("확인", (dialog, which) -> {
            int hour = numberPickerHour.getValue();
            int minute = numberPickerMinute.getValue() * 30; // 00 또는 30
            String time = String.format(Locale.getDefault(), "%02d:%02d", hour, minute);
            if (isStartTime) {
                selectedStartTime = time;
                editTextStartTime.setText(time);
            } else {
                selectedEndTime = time;
                editTextEndTime.setText(time);
            }
        });
        builder.setNegativeButton("취소", null);
        builder.show();
    }

    // 예약을 확인하고 진행하는 메서드
    private void confirmBooking() {
        if (selectedDate == null || selectedStartTime == null || selectedEndTime == null) {
            Toast.makeText(this, "날짜와 시간을 선택해 주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        // 시작 시간과 종료 시간을 24시간 형식으로 변환하여 비교
        try {
            int startHour = convertTo24Hour(selectedStartTime);
            int startMinute = convertToMinute(selectedStartTime);
            int endHour = convertTo24Hour(selectedEndTime);
            int endMinute = convertToMinute(selectedEndTime);

            if (endHour < startHour || (endHour == startHour && endMinute <= startMinute)) {
                Toast.makeText(this, "종료 시간은 시작 시간보다 이후여야 합니다.", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            Toast.makeText(this, "시간 파싱에 실패했습니다.", Toast.LENGTH_SHORT).show();
            return;
        }

        // 이미 예약된 시간인지 확인
        db.collection("books")
                .whereEqualTo("studioId", studioId)
                .whereEqualTo("bookDate", selectedDate)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<String> bookedTimeSlots = getBookedTimeSlots(task.getResult());

                        // 예약 시간대와 기존 예약 시간대가 겹치는지 확인
                        List<String> requestedTimeSlots = generateTimeSlots(selectedStartTime, selectedEndTime);
                        for (String slot : requestedTimeSlots) {
                            if (bookedTimeSlots.contains(slot)) {
                                Toast.makeText(StudioRentalActivity.this, "이미 예약된 시간입니다. 전체 일정을 확인해주세요.", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        }

                        // 예약이 중복되지 않았으므로 예약 진행
                        String bookDetails = String.format(Locale.getDefault(), "날짜: %s\n시간: %s ~ %s", selectedDate, selectedStartTime, selectedEndTime);

                        new AlertDialog.Builder(this)
                                .setTitle("스튜디오 대여")
                                .setMessage(bookDetails)
                                .setPositiveButton("확인", (dialog, which) -> {
                                    rentStudio(selectedDate, selectedStartTime, selectedEndTime);
                                })
                                .setNegativeButton("취소", null)
                                .show();
                    } else {
                        Log.e(TAG, "Error getting documents: ", task.getException());
                        Toast.makeText(StudioRentalActivity.this, "예약 확인 중 오류가 발생했습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // 24시간 형식으로 시간 변환
    private int convertTo24Hour(String time) throws ParseException {
        SimpleDateFormat sdf24 = new SimpleDateFormat("HH:mm", Locale.KOREA);
        Date date = sdf24.parse(time);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.HOUR_OF_DAY);
    }

    // 분을 반환하는 메서드
    private int convertToMinute(String time) throws ParseException {
        SimpleDateFormat sdf24 = new SimpleDateFormat("HH:mm", Locale.KOREA);
        Date date = sdf24.parse(time);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.MINUTE);
    }

    // 예약된 시간대를 리스트로 반환하는 메서드
    private List<String> getBookedTimeSlots(QuerySnapshot querySnapshot) {
        List<String> bookedTimeSlots = new ArrayList<>();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());

        for (DocumentSnapshot document : querySnapshot) {
            try {
                String docStartTime = document.getString("startTime");
                String docEndTime = document.getString("endTime");
                Date start = timeFormat.parse(docStartTime);
                Date end = timeFormat.parse(docEndTime);
                Calendar startCal = Calendar.getInstance();
                startCal.setTime(start);

                while (startCal.getTime().before(end)) {
                    bookedTimeSlots.add(timeFormat.format(startCal.getTime()));
                    startCal.add(Calendar.MINUTE, 30);
                }
            } catch (Exception e) {
                Log.e(TAG, "시간 파싱 오류: " + e.getMessage());
            }
        }
        return bookedTimeSlots;
    }

    // 주어진 시간대에 대해 30분 단위로 나누는 메서드
    private List<String> generateTimeSlots(String startTime, String endTime) {
        List<String> timeSlots = new ArrayList<>();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
        try {
            Date start = timeFormat.parse(startTime);
            Date end = timeFormat.parse(endTime);
            Calendar startCal = Calendar.getInstance();
            startCal.setTime(start);
            while (startCal.getTime().before(end)) {
                timeSlots.add(timeFormat.format(startCal.getTime()));
                startCal.add(Calendar.MINUTE, 30);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return timeSlots;
    }

    // 스튜디오 예약 트랜잭션 처리
    private void rentStudio(String bookDate, String startTime, String endTime) {
        db.collection("books")
                .whereEqualTo("studioId", studioId)
                .whereEqualTo("bookDate", bookDate)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<String> bookedTimeSlots = getBookedTimeSlots(task.getResult());

                        db.runTransaction(transaction -> {
                            // 요청된 시간대가 이미 예약되었는지 확인
                            List<String> requestedTimeSlots = generateTimeSlots(startTime, endTime);
                            for (String slot : requestedTimeSlots) {
                                if (bookedTimeSlots.contains(slot)) {
                                    throw new FirebaseFirestoreException("이미 예약된 시간대입니다.", FirebaseFirestoreException.Code.ABORTED);
                                }
                            }

                            // 예약 정보 객체 생성 및 books 컬렉션에 추가
                            String bookId = db.collection("books").document().getId();
                            Timestamp bookTimestamp = Timestamp.now();
                            Map<String, Object> rental = new HashMap<>();
                            rental.put("bookDate", bookDate);
                            rental.put("startTime", startTime);
                            rental.put("endTime", endTime);
                            rental.put("bookId", bookId);
                            rental.put("bookPurpose", "사진관 대여");
                            rental.put("bookTimestamp", bookTimestamp);
                            rental.put("customerId", customerId);
                            rental.put("studioId", studioId);

                            DocumentReference newBookingRef = db.collection("books").document(bookId);
                            transaction.set(newBookingRef, rental);

                            return null;
                        }).addOnSuccessListener(aVoid -> {
                            Toast.makeText(StudioRentalActivity.this, "예약되었습니다.", Toast.LENGTH_SHORT).show();
                            Toast.makeText(StudioRentalActivity.this, "예약 조회에서 확인 가능합니다.", Toast.LENGTH_SHORT).show();
                            finish();
                        }).addOnFailureListener(e -> {
                            if (e instanceof FirebaseFirestoreException &&
                                    ((FirebaseFirestoreException) e).getCode() == FirebaseFirestoreException.Code.ABORTED) {
                                Toast.makeText(StudioRentalActivity.this, "이미 예약된 시간대입니다. 다른 시간대를 선택해 주세요.", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(StudioRentalActivity.this, "사진관 대여에 실패했습니다.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        Log.e(TAG, "Error getting documents: ", task.getException());
                        Toast.makeText(StudioRentalActivity.this, "예약 확인 중 오류가 발생했습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // 요일을 반환하는 메서드
    private String getDayOfWeek(int year, int month, int dayOfMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, dayOfMonth);
        Date date = calendar.getTime();
        return new SimpleDateFormat("EEE", Locale.getDefault()).format(date);
    }
}
