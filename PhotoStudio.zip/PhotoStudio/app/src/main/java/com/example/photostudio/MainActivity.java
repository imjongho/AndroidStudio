package com.example.photostudio;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;

public class MainActivity extends AppCompatActivity {

    private TextView textLocation;
    private TextView textStudioName;
    private TextView textManager;
    private TextView textManagerPhone;
    private Button buttonSelectStudio; // 사진관 선택(등록)
    private Button buttonLogout; // 로그아웃 버튼
    private String customerId; // 고객 아이디
    private String studioId; // 사진관 아이디
    private FirebaseFirestore db; // Firestore 데이터베이스 인스턴스
    private static final int REQUEST_SELECT_STUDIO = 1; // 사진관 선택 요청 코드

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseApp.initializeApp(this); // Firebase 초기화

        textLocation = findViewById(R.id.text_location);
        textStudioName = findViewById(R.id.text_studio_name);
        textManager = findViewById(R.id.text_manager);
        textManagerPhone = findViewById(R.id.text_manager_phone);
        buttonSelectStudio = findViewById(R.id.buttonSelectStudio);
        buttonLogout = findViewById(R.id.buttonLogout);

        db = FirebaseFirestore.getInstance(); // Firestore 인스턴스 초기화

        // 인텐트로부터 고객 아이디를 가져옴
        customerId = getIntent().getStringExtra("customerId");
        if (customerId == null) {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        // 인텐트로부터 사진관 아이디를 가져옴
        studioId = getIntent().getStringExtra("studioId");
        if (studioId == null) {
            buttonSelectStudio.setVisibility(View.VISIBLE);
            buttonSelectStudio.setText("사진관 선택");
        } else {
            buttonSelectStudio.setVisibility(View.VISIBLE);
            buttonSelectStudio.setText("사진관 변경");
            // 선택된 사진관의 정보를 표시
            displayStudioInfo();
        }

        // 사진관 등록/변경 버튼 클릭시 사진관 선택 화면으로 이동
        buttonSelectStudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SelectStudioActivity.class);
                startActivityForResult(intent, REQUEST_SELECT_STUDIO); // 선택을 위해 startActivityForResult 사용
            }
        });

        // 로그아웃 버튼 클릭시 로그인 화면으로 이동
        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }


    // 선택된 사진관의 정보를 표시하는 메서드
    private void displayStudioInfo() {
        db.collection("studios").document(studioId).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if (documentSnapshot.exists()) {
                    String studioName = documentSnapshot.getString("name");
                    String studioAddress = documentSnapshot.getString("address");
                    String managerName = documentSnapshot.getString("manager");
                    String managerPhone = documentSnapshot.getString("phone");
                    // 정보를 텍스트 뷰에 설정
                    textStudioName.setText(studioName);
                    textManager.setText("담당자: " + managerName);
                    textManagerPhone.setText("전화번호: " + managerPhone);
                    textLocation.setText("주소: " + studioAddress);
                } else {
                    Toast.makeText(MainActivity.this, "사진관 정보를 가져올 수 없습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(MainActivity.this, "사진관 정보를 가져오는데 실패했습니다.", Toast.LENGTH_SHORT).show();
            }
        });
    }


    // onActivityResult 메서드 추가
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SELECT_STUDIO && resultCode == RESULT_OK) {
            studioId = data.getStringExtra("studioId");
            if (studioId != null) {
                buttonSelectStudio.setText("사진관 변경");
                displayStudioInfo();
            }
        }
    }


    // 각 버튼 클릭 시 호출되는 메서드
    public void onButtonClicked(View view) {
        int id = view.getId();
        Intent intent;

        // "내 정보" 버튼 클릭 시 처리
        if (id == R.id.my_info) {
            intent = new Intent(MainActivity.this, UserInfoActivity.class);
            intent.putExtra("customerId", customerId);
            intent.putExtra("studioId", studioId);
            startActivity(intent);
        } else {
            // 사진관 선택 안 하면 나머지 버튼이 기능을 못하게 하기.
            if (studioId == null) {
                Toast.makeText(this, "사진관을 선택해 주세요.", Toast.LENGTH_SHORT).show();
                return;
            }

            // 나머지 버튼 클릭 시 처리
            if (id == R.id.schedule) {
                intent = new Intent(MainActivity.this, ScheduleActivity.class);
                intent.putExtra("studioId", studioId);
                startActivity(intent);
            } else if (id == R.id.visit_book) {
                intent = new Intent(MainActivity.this, VisitBookActivity.class);
                intent.putExtra("customerId", customerId);
                intent.putExtra("studioId", studioId);
                startActivity(intent);
            } else if (id == R.id.studio_book) {
                intent = new Intent(MainActivity.this, StudioRentalActivity.class);
                intent.putExtra("customerId", customerId);
                intent.putExtra("studioId", studioId);
                startActivity(intent);
            } else if (id == R.id.book_info) {
                intent = new Intent(MainActivity.this, BookInfoActivity.class);
                intent.putExtra("customerId", customerId);
                intent.putExtra("studioId", studioId);
                startActivity(intent);
            } else if (id == R.id.reference_photo) {
                intent = new Intent(MainActivity.this, ReferencePhotoActivity.class);
                intent.putExtra("studioId", studioId);
                startActivity(intent);
            }
        }
    }



}

