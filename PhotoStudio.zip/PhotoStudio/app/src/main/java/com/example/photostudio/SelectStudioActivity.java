package com.example.photostudio;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SelectStudioActivity extends AppCompatActivity {

    private FirebaseFirestore db; // Firestore 인스턴스
    private RecyclerView recyclerView; // RecyclerView 인스턴스
    private StudioAdapter adapter; // RecyclerView 어댑터
    private List<Map<String, Object>> studioList; // 스튜디오 데이터를 담을 리스트
    private List<Map<String, Object>> filteredStudioList; // 필터링된 스튜디오 데이터를 담을 리스트
    private EditText searchEditText; // 검색어 입력창
    private Button searchButton; // 검색 버튼

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_studio);
        db = FirebaseFirestore.getInstance();

        // 검색 관련 UI 요소 초기화
        searchEditText = findViewById(R.id.searchEditText);
        searchButton = findViewById(R.id.searchButton);

        // RecyclerView 초기화
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        studioList = new ArrayList<>();
        filteredStudioList = new ArrayList<>();
        adapter = new StudioAdapter(filteredStudioList);
        recyclerView.setAdapter(adapter);

        // 모든 사진관 데이터 로드
        loadAllStudios();

        // 검색 버튼 클릭 이벤트 처리
        searchButton.setOnClickListener(v -> filterStudios());

        // 검색어가 변경될 때마다 필터링
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterStudios();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    // Firestore에서 모든 사진관 데이터를 불러오는 메서드
    private void loadAllStudios() {
        db.collection("studios").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                studioList.clear();
                for (QueryDocumentSnapshot document : task.getResult()) {
                    Map<String, Object> studio = new HashMap<>(document.getData());
                    studio.put("studioId", document.getId());
                    studioList.add(studio);
                }
                filterStudios(); // 초기 데이터 로드 후 필터링
            } else {
                Toast.makeText(SelectStudioActivity.this, "문서 가져오기 오류: " + task.getException(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // 검색어를 기반으로 스튜디오 리스트를 필터링하는 메서드
    private void filterStudios() {
        String searchText = searchEditText.getText().toString().toLowerCase();
        filteredStudioList.clear();

        if (searchText.isEmpty()) {
            filteredStudioList.addAll(studioList);
        } else {
            for (Map<String, Object> studio : studioList) {
                String studioName = ((String) studio.get("name")).toLowerCase();
                String studioAddress = ((String) studio.get("address")).toLowerCase();
                if (studioName.contains(searchText) || studioAddress.contains(searchText)) {
                    filteredStudioList.add(studio);
                }
            }
        }

        adapter.notifyDataSetChanged(); // 어댑터 갱신
    }

    // RecyclerView 어댑터 클래스
    private class StudioAdapter extends RecyclerView.Adapter<StudioAdapter.StudioViewHolder> {

        private List<Map<String, Object>> studioList;

        StudioAdapter(List<Map<String, Object>> studioList) {
            this.studioList = studioList;
        }

        @NonNull
        @Override
        public StudioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item2, parent, false);
            return new StudioViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull StudioViewHolder holder, int position) {
            Map<String, Object> studio = studioList.get(position);
            holder.tvStudioName.setText((String) studio.get("name"));
            holder.tvStudioAddress.setText("주소: " + (String) studio.get("address"));
            holder.tvManager.setText("담당자: " + (String) studio.get("manager"));
            holder.tvContact.setText("전화번호: " + (String) studio.get("phone"));
            holder.imgStudio.setImageResource(R.drawable.ic_launcher_foreground); // 기본 이미지 설정

            // 사진관 선택 버튼 클릭 시
            holder.btnSelectStudio.setOnClickListener(v -> {
                String studioId = (String) studio.get("studioId");
                Intent intent = new Intent();
                intent.putExtra("studioId", studioId); // 선택한 사진관 아이디 넘기기
                setResult(RESULT_OK, intent);
                finish();
            });
        }

        @Override
        public int getItemCount() {
            return studioList.size();
        }

        // ViewHolder 클래스
        class StudioViewHolder extends RecyclerView.ViewHolder {

            TextView tvStudioName, tvStudioAddress, tvManager, tvContact;
            ImageView imgStudio;
            Button btnSelectStudio;

            StudioViewHolder(@NonNull View itemView) {
                super(itemView);
                tvStudioName = itemView.findViewById(R.id.tvStudioName);
                tvStudioAddress = itemView.findViewById(R.id.tvStudioAddress);
                tvManager = itemView.findViewById(R.id.tvManager);
                tvContact = itemView.findViewById(R.id.tvContact);
                imgStudio = itemView.findViewById(R.id.imgStudio);
                btnSelectStudio = itemView.findViewById(R.id.btnSelectStudio);
            }
        }
    }


}
