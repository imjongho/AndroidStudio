package com.example.photostudio;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.GridLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.Transaction;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;

public class VisitBookActivity extends AppCompatActivity {

    private GridLayout morningSlotsGrid;
    private GridLayout afternoonSlotsGrid;
    private Button reserveButton;
    private Button selectedTimeButton;
    private String selectedDate;
    private String selectedTime;
    private TextView morningLabel;
    private TextView afternoonLabel;
    private TextView purposeLabel;
    private TableLayout purposeTable;
    private TextView noteLabel;
    private List<String> selectedPurposes;

    private FirebaseFirestore db;
    private String customerId;
    private String studioId;

    private static final String TAG = "VisitBookActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.visit_book);

        db = FirebaseFirestore.getInstance();
        customerId = getIntent().getStringExtra("customerId");
        studioId = getIntent().getStringExtra("studioId");

        morningSlotsGrid = findViewById(R.id.morning_slots_grid);
        afternoonSlotsGrid = findViewById(R.id.afternoon_slots_grid);
        reserveButton = findViewById(R.id.btn_reserve);
        morningLabel = findViewById(R.id.morning_label);
        afternoonLabel = findViewById(R.id.afternoon_label);
        purposeLabel = findViewById(R.id.purpose_label);
        purposeTable = findViewById(R.id.purpose_table);
        noteLabel = findViewById(R.id.note_label);
        selectedPurposes = new ArrayList<>();

        // 달력에서 날짜가 선택될 때 호출되는 리스너 설정
        CalendarView calendarView = findViewById(R.id.calendarView);
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = String.format("%d년 %d월 %d일(%s)", year, month + 1, dayOfMonth, getDayOfWeek(year, month, dayOfMonth));
            Log.d(TAG, "Selected date: " + selectedDate);
            updateUIForSelectedDate();
            generateTimeSlots(); // 시간대 버튼 생성
            generatePurposeOptions(); // 방문 목적 옵션 생성
        });

        // 예약하기 버튼 클릭 리스너 설정
        reserveButton.setOnClickListener(v -> {
            if (selectedTime != null && !selectedPurposes.isEmpty()) {
                String startTime = selectedTime;
                String endTime = calculateEndTime(selectedTime);

                String bookDetails = String.format("날짜: %s\n시간: %s ~ %s\n목적: %s",
                        selectedDate, startTime, endTime, String.join("/", selectedPurposes));

                // 예약 확인 다이얼로그 표시
                new AlertDialog.Builder(this)
                        .setTitle("방문 예약")
                        .setMessage(bookDetails)
                        .setPositiveButton("확인", (dialog, which) -> {
                            // 예약 정보를 저장하기 전에 예약된 시간대 확인
                            checkAndSaveBookingData(selectedDate, startTime, endTime, String.join("/", selectedPurposes));
                        })
                        .setNegativeButton("취소", null)
                        .show();
            } else {
                // 사용자가 시간과 방문 목적을 선택하지 않은 경우
                Toast.makeText(VisitBookActivity.this, "시간과 방문 목적을 선택해 주세요", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // 날짜 선택 시 UI 업데이트
    private void updateUIForSelectedDate() {
        morningLabel.setVisibility(View.VISIBLE);
        afternoonLabel.setVisibility(View.VISIBLE);
        purposeLabel.setVisibility(View.VISIBLE);
        purposeTable.setVisibility(View.VISIBLE);
        noteLabel.setVisibility(View.VISIBLE);
        reserveButton.setVisibility(View.VISIBLE);
    }

    // 예약된 시간대 확인 후 예약 데이터를 저장하는 메서드
    private void checkAndSaveBookingData(String bookDate, String startTime, String endTime, String bookPurpose) {
        db.collection("books")
                .whereEqualTo("studioId", studioId)
                .whereEqualTo("bookDate", bookDate)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<String> bookedTimeSlots = getBookedTimeSlots(task.getResult());

                        // 요청된 시간대가 이미 예약되었는지 확인
                        List<String> requestedTimeSlots = generateTimeSlots(startTime, endTime);
                        for (String slot : requestedTimeSlots) {
                            if (bookedTimeSlots.contains(slot)) {
                                Toast.makeText(VisitBookActivity.this, "이미 예약된 시간대입니다. 다른 시간대를 선택해 주세요.", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        }

                        // 예약 정보 저장
                        saveBookingData(bookDate, startTime, endTime, bookPurpose);
                    } else {
                        Log.e(TAG, "Error getting documents: ", task.getException());
                    }
                });
    }

    // 예약된 시간대를 리스트로 반환하는 메서드
    private List<String> getBookedTimeSlots(QuerySnapshot querySnapshot) {
        List<String> bookedTimeSlots = new ArrayList<>();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());

        for (DocumentSnapshot document : querySnapshot) {
            try {
                String docStartTime = document.getString("startTime");
                String docEndTime = document.getString("endTime");
                Date start = timeFormat.parse(docStartTime);
                Date end = timeFormat.parse(docEndTime);
                Calendar startCal = Calendar.getInstance();
                startCal.setTime(start);

                while (startCal.getTime().before(end)) {
                    bookedTimeSlots.add(timeFormat.format(startCal.getTime()));
                    startCal.add(Calendar.MINUTE, 30);
                }
            } catch (Exception e) {
                Log.e(TAG, "시간 파싱 오류: " + e.getMessage());
            }
        }
        return bookedTimeSlots;
    }

    // 예약 데이터를 저장하는 메서드
    private void saveBookingData(String bookDate, String startTime, String endTime, String bookPurpose) {
        // 트랜잭션을 사용해 동시성 문제 해결
        db.runTransaction((Transaction.Function<Void>) transaction -> {
            // 예약 정보 객체 생성 및 books 컬렉션에 추가
            String bookId = db.collection("books").document().getId();
            Timestamp bookTimestamp = Timestamp.now();
            Map<String, Object> booking = new HashMap<>();
            booking.put("bookDate", bookDate);
            booking.put("startTime", startTime);
            booking.put("endTime", endTime);
            booking.put("bookId", bookId);
            booking.put("bookPurpose", bookPurpose);
            booking.put("bookTimestamp", bookTimestamp);
            booking.put("customerId", customerId);
            booking.put("studioId", studioId);

            DocumentReference newBookingRef = db.collection("books").document(bookId);
            transaction.set(newBookingRef, booking);

            return null;
        }).addOnSuccessListener(aVoid -> {
            Toast.makeText(VisitBookActivity.this, "예약되었습니다.", Toast.LENGTH_SHORT).show();
            navigateToMainActivity();
        }).addOnFailureListener(e -> {
            Toast.makeText(VisitBookActivity.this, "예약 저장 실패: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    // 예약 후 메인 액티비티로 이동하는 메서드
    private void navigateToMainActivity() {
        Intent intent = new Intent(VisitBookActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("customerId", customerId);
        intent.putExtra("studioId", studioId);
        startActivity(intent);
        finish();
    }

    // 시간대 버튼들을 생성하는 메서드
    private void generateTimeSlots() {
        morningSlotsGrid.removeAllViews();
        afternoonSlotsGrid.removeAllViews();

        String[] morningSlots = {"09:00", "09:30", "10:00", "10:30", "11:00", "11:30"};
        String[] afternoonSlots = {"13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00"};

        Log.d(TAG, "Formatted date: " + selectedDate);

        db.collection("books")
                .whereEqualTo("studioId", studioId)
                .whereEqualTo("bookDate", selectedDate)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<String> bookedTimeSlots = getBookedTimeSlots(task.getResult());

                        Log.d(TAG, "Booked time slots: " + bookedTimeSlots.toString());

                        // 오전 시간대 버튼 생성
                        createButtonsForSlots(morningSlotsGrid, morningSlots, bookedTimeSlots);
                        morningSlotsGrid.setVisibility(View.VISIBLE);

                        // 오후 시간대 버튼 생성
                        createButtonsForSlots(afternoonSlotsGrid, afternoonSlots, bookedTimeSlots);
                        afternoonSlotsGrid.setVisibility(View.VISIBLE);
                    } else {
                        Log.e(TAG, "Error getting documents: ", task.getException());
                    }
                });
    }

    // 방문 목적 옵션들을 생성하는 메서드
    private void generatePurposeOptions() {
        purposeTable.removeAllViews();

        String[][] purposes = {
                {"증명사진", "15,000원", "3(cm)*4(cm)/8장"},
                {"주민등록증", "15,000원", "3.5(cm)*4.5(cm)/8장"},
                {"운전면허증", "15,000원", "3.5(cm)*4.5(cm)/8장"},
                {"여권사진", "15,000원", "3.5(cm)*4.5(cm)/8장"},
                {"가족사진", "20,0000원(기본)", "컨셉 촬영/액자 구성", "액자의 크기나 종류는 선택할 수 있습니다."},
                {"기타"}
        };

        for (String[] purpose : purposes) {
            TableRow row = new TableRow(this);
            row.setPadding(8, 8, 8, 8);

            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(purpose[0]);
            checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    selectedPurposes.add(purpose[0]);
                } else {
                    selectedPurposes.remove(purpose[0]);
                }
            });
            TableRow.LayoutParams params = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f);
            checkBox.setLayoutParams(params);

            TextView priceView = new TextView(this);
            priceView.setText(purpose.length > 1 ? purpose[1] : "상담 진행");
            priceView.setPadding(16, 0, 16, 0);
            priceView.setLayoutParams(params);

            row.addView(checkBox);
            row.addView(priceView);
            purposeTable.addView(row);

            // 설명이 있을 경우 별도의 행 추가
            if (purpose.length > 2) {
                TableRow detailRow = new TableRow(this);
                detailRow.setPadding(8, 8, 8, 8);

                TextView detailView = new TextView(this);
                StringBuilder detailBuilder = new StringBuilder();
                for (int i = 2; i < purpose.length; i++) {
                    detailBuilder.append(purpose[i]).append("\n");
                }
                detailView.setText(detailBuilder.toString().trim()); // 마지막 개행 문자 제거
                detailView.setPadding(16, 0, 16, 0);
                TableRow.LayoutParams detailParams = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
                detailView.setLayoutParams(detailParams);

                detailRow.addView(detailView);
                purposeTable.addView(detailRow);
            }
        }
    }

    // 주어진 시간대에 대해 버튼들을 생성하는 메서드
    private void createButtonsForSlots(GridLayout gridLayout, String[] timeSlots, List<String> bookedTimeSlots) {
        for (String timeSlot : timeSlots) {
            Button button = new Button(this);
            button.setText(timeSlot);

            // GridLayout의 LayoutParams 설정
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0;
            params.height = GridLayout.LayoutParams.WRAP_CONTENT;
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            params.setMargins(8, 8, 8, 8); // 버튼 사이에 여백 추가
            button.setLayoutParams(params);

            if (bookedTimeSlots.contains(timeSlot)) {
                button.setBackgroundColor(Color.GRAY);
                button.setEnabled(false);
                Log.d(TAG, "Disabled time slot: " + timeSlot);
            } else {
                button.setBackgroundColor(Color.WHITE);
                button.setTextColor(Color.parseColor("#333333")); // 버튼 텍스트 색상 설정
                button.setOnClickListener(v -> selectTimeSlot(button));
            }

            gridLayout.addView(button);
        }
    }

    // 시간대 버튼이 선택되었을 때 호출되는 메서드
    private void selectTimeSlot(Button button) {
        if (selectedTimeButton != null) {
            selectedTimeButton.setBackgroundColor(Color.WHITE); // 이전 선택된 버튼의 배경색 초기화
            selectedTimeButton.setTextColor(Color.parseColor("#333333")); // 이전 선택된 버튼의 텍스트 색상 초기화
        }
        selectedTimeButton = button;
        selectedTime = button.getText().toString();
        button.setBackgroundColor(Color.parseColor("#66BB6A")); // 선택된 버튼의 배경색 변경
        button.setTextColor(Color.WHITE); // 선택된 버튼의 텍스트 색상 변경
    }

    // 종료 시간 계산 메서드
    private String calculateEndTime(String startTime) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault()); // 시간 형식을 24시간 형식으로 변경
            Date startDate = sdf.parse(startTime);
            long startTimeInMillis = startDate.getTime();
            long endTimeInMillis = startTimeInMillis + (30 * 60 * 1000); // 30분 추가
            Date endDate = new Date(endTimeInMillis);
            return sdf.format(endDate);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    // 요일을 반환하는 메서드
    private String getDayOfWeek(int year, int month, int dayOfMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, dayOfMonth);
        Date date = calendar.getTime();
        return new SimpleDateFormat("EEE", Locale.getDefault()).format(date);
    }

    // 주어진 시간대에 대해 30분 단위로 나누는 메서드
    private List<String> generateTimeSlots(String startTime, String endTime) {
        List<String> timeSlots = new ArrayList<>();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
        try {
            Date start = timeFormat.parse(startTime);
            Date end = timeFormat.parse(endTime);
            Calendar startCal = Calendar.getInstance();
            startCal.setTime(start);
            while (startCal.getTime().before(end)) {
                timeSlots.add(timeFormat.format(startCal.getTime()));
                startCal.add(Calendar.MINUTE, 30);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return timeSlots;
    }
}
