package com.example.photostudio;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.Timestamp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class BookInfoActivity extends AppCompatActivity {

    private RecyclerView recyclerView; // 예약 정보를 표시하는 RecyclerView
    private FirebaseFirestore db;
    private String customerId; // 사용자 ID
    private String studioId; // 스튜디오 ID
    private BookAdapter bookAdapter; // RecyclerView에 연결된 어댑터
    private List<QueryDocumentSnapshot> bookList; // 예약 정보 목록
    private SimpleDateFormat sdf; // 날짜 형식 변환을 위한 변수

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.book_info);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = FirebaseFirestore.getInstance();
        customerId = getIntent().getStringExtra("customerId");
        studioId = getIntent().getStringExtra("studioId");

        bookList = new ArrayList<>(); // 예약 정보를 담을 ArrayList 초기화
        bookAdapter = new BookAdapter(bookList); // 어댑터 초기화
        recyclerView.setAdapter(bookAdapter); // RecyclerView에 어댑터 설정

        sdf = new SimpleDateFormat("yyyy년 M월 d일(E)", Locale.KOREA); // SimpleDateFormat 초기화

        loadBooks(); // 예약 정보 불러오는 메서드 호출
    }

    private void loadBooks() {
        if (customerId == null || studioId == null) {
            Log.e("Firestore", "사용자 ID 또는 스튜디오 ID를 찾을 수 없습니다."); // 고객 ID나 스튜디오 ID가 없을 경우 에러 로그 출력 후 종료
            return;
        }

        Log.d("Firestore", "예약 정보를 불러옵니다. 고객 ID: " + customerId + ", 스튜디오 ID: " + studioId);

        // Firebase Firestore에서 해당 사용자의 예약 정보를 가져오는 쿼리 실행
        db.collection("books")
                .whereEqualTo("customerId", customerId)
                .whereEqualTo("studioId", studioId) // 스튜디오 ID로 필터링 추가
                .orderBy("bookTimestamp", Query.Direction.DESCENDING) // 최신순 정렬, 즉 가장 최근에 예약한 정보가 맨 위에 있음
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) { // 작업이 성공한 경우
                        bookList.clear(); // 기존의 예약 정보 목록을 초기화
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            bookList.add(document); // 가져온 예약 정보를 목록에 추가
                        }
                        Log.d("Firestore", "불러온 예약 정보 수: " + bookList.size());

                        bookAdapter.notifyDataSetChanged(); // 어댑터에 데이터 변경을 알림
                        Log.d("Firestore", "예약 정보를 성공적으로 불러왔습니다.");
                    } else {
                        Log.e("Firestore", "예약 정보를 불러오는데 실패했습니다: ", task.getException());
                    }
                });
    }

    private void loadStudioInfo(String studioId, StudioInfoCallback callback) {
        db.collection("studios").document(studioId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    String studioName = document.getString("name");
                    String manager = document.getString("manager");
                    String contact = document.getString("phone");
                    callback.onCallback(studioName, manager, contact);
                } else {
                    Log.e("Firestore", "스튜디오 정보를 찾을 수 없습니다. 스튜디오 ID: " + studioId);
                    callback.onCallback("Unknown Studio", "Unknown Manager", "Unknown Contact");
                }
            } else {
                Log.e("Firestore", "스튜디오 정보를 가져오는데 실패했습니다: ", task.getException());
                callback.onCallback("Unknown Studio", "Unknown Manager", "Unknown Contact");
            }
        });
    }

    interface StudioInfoCallback {
        void onCallback(String studioName, String manager, String contact);
    }

    private class BookAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder> {

        private List<QueryDocumentSnapshot> bookList; // 예약 정보 목록을 저장하는 리스트
        private SimpleDateFormat sdf; // 날짜 형식 변환을 위한 변수

        public BookAdapter(List<QueryDocumentSnapshot> bookList) {
            this.bookList = bookList;
            this.sdf = new SimpleDateFormat("yyyy년 M월 d일(EEE)", Locale.KOREA); // SimpleDateFormat 초기화
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // RecyclerView의 각 아이템 뷰를 생성하여 ViewHolder 객체를 생성하여 반환
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            // 각 아이템 뷰에 데이터를 바인딩
            QueryDocumentSnapshot document = bookList.get(position);
            String bookDate = document.getString("bookDate");
            String startTime = document.getString("startTime");
            String endTime = document.getString("endTime");
            String bookPurpose = document.getString("bookPurpose");

            // 스튜디오 ID 가져오기
            String studioId = document.getString("studioId");

            // 스튜디오 정보 로드하여 설정
            loadStudioInfo(studioId, (studioName, manager, contact) -> {
                holder.tvStudioName.setText(studioName);
                holder.tvManagerAndContact.setText(manager + "   문의: " + contact);
            });

            holder.tvBookDate.setText(String.format("일정: %s %s ~ %s", bookDate, startTime, endTime));
            holder.tvBookPurpose.setText("목적: " + bookPurpose);

            // Timestamp 설정
            Timestamp bookTimestamp = document.getTimestamp("bookTimestamp");
            if (bookTimestamp != null) {
                Date date = bookTimestamp.toDate();
                SimpleDateFormat timestampSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.KOREA);
                String formattedTimestamp = timestampSdf.format(date);
                holder.tvTimestamp.setText(formattedTimestamp);
            } else {
                holder.tvTimestamp.setText("타임스탬프 없음");
            }

            // 현재 시간과 비교하여 과거의 예약인지 확인
            try {
                if (bookDate != null && startTime != null) {
                    // bookDate와 startTime을 사용하여 정확한 날짜 및 시간 생성
                    SimpleDateFormat fullDateFormat = new SimpleDateFormat("yyyy년 M월 d일(E) HH:mm", Locale.KOREA);
                    Date startDateTime = fullDateFormat.parse(bookDate + " " + startTime);
                    if (startDateTime != null && startDateTime.before(new Date())) {
                        // 예약이 과거일 경우
                        holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), android.R.color.darker_gray));
                        holder.btnCancelBook.setText("삭제");
                    } else {
                        holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), android.R.color.white));
                        holder.btnCancelBook.setText("예약 취소");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            holder.btnCancelBook.setOnClickListener(v -> {
                // 예약 취소 버튼 클릭 시 동작
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                db.collection("books").document(document.getId())
                        .delete()
                        .addOnSuccessListener(aVoid -> {
                            bookList.remove(position);
                            notifyItemRemoved(position);
                            notifyItemRangeChanged(position, bookList.size());
                            Log.d("Firestore", "예약이 성공적으로 취소되었습니다.");
                        })
                        .addOnFailureListener(e -> {
                            Log.e("Firestore", "예약 취소에 실패했습니다: ", e);
                        });
            });
        }

        @Override
        public int getItemCount() {
            return bookList.size(); // 목록의 크기 반환
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            // ViewHolder 클래스 정의
            public TextView tvStudioName;
            public TextView tvManagerAndContact;
            public TextView tvBookDate;
            public TextView tvBookPurpose;
            public TextView tvTimestamp;
            public Button btnCancelBook;

            public ViewHolder(View view) {
                super(view);
                // 각 뷰 요소들을 findViewById를 통해 연결
                tvStudioName = view.findViewById(R.id.tvStudioName);
                tvManagerAndContact = view.findViewById(R.id.tvManagerAndContact);
                tvBookDate = view.findViewById(R.id.tvBookDate);
                tvBookPurpose = view.findViewById(R.id.tvBookPurpose);
                tvTimestamp = view.findViewById(R.id.tvTimestamp);
                btnCancelBook = view.findViewById(R.id.btnCancelBook);
            }
        }
    }
}
