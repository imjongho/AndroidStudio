package com.example.photostudio;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class ScheduleActivity extends AppCompatActivity {

    private static final String TAG = "ScheduleActivity";
    private CalendarView calendarView;
    private TextView textSelectedDate;
    private Button btnPreviousDay, btnNextDay;
    private FirebaseFirestore db;
    private SimpleDateFormat dateFormat;
    private Calendar selectedDate;
    private String studioId;

    // TextView array 선언
    private TextView[] timeSlots = new TextView[48];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule);

        calendarView = findViewById(R.id.calendarView);
        textSelectedDate = findViewById(R.id.textSelectedDate);
        btnPreviousDay = findViewById(R.id.btnPreviousDay);
        btnNextDay = findViewById(R.id.btnNextDay);

        db = FirebaseFirestore.getInstance();
        dateFormat = new SimpleDateFormat("yyyy년 M월 d일(E)", Locale.getDefault());
        selectedDate = Calendar.getInstance();

        // 인텐트로부터 스튜디오 ID를 받아옴
        studioId = getIntent().getStringExtra("studioId");
        if (studioId == null) {
            Toast.makeText(this, "스튜디오 ID를 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initializeTimeSlots();
        updateSelectedDate();
        // 현재 날짜로 초기화
        calendarView.setDate(selectedDate.getTimeInMillis(), false, true);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate.set(year, month, dayOfMonth);
            updateSelectedDate();
        });

        btnPreviousDay.setOnClickListener(v -> {
            selectedDate.add(Calendar.DAY_OF_MONTH, -1);
            updateSelectedDate();
            calendarView.setDate(selectedDate.getTimeInMillis(), false, true);
        });

        btnNextDay.setOnClickListener(v -> {
            selectedDate.add(Calendar.DAY_OF_MONTH, 1);
            updateSelectedDate();
            calendarView.setDate(selectedDate.getTimeInMillis(), false, true);
        });
    }

    private void initializeTimeSlots() {
        for (int i = 0; i < 24; i++) {
            String hour = String.format(Locale.getDefault(), "%02d", i);
            timeSlots[i * 2] = findViewById(getResources().getIdentifier("_" + hour + "_00", "id", getPackageName()));
            timeSlots[i * 2 + 1] = findViewById(getResources().getIdentifier("_" + hour + "_30", "id", getPackageName()));
            Log.d(TAG, "TextView 초기화: _" + hour + "_00, _" + hour + "_30");
        }
    }

    private void updateSelectedDate() {
        String dateStr = dateFormat.format(selectedDate.getTime());
        textSelectedDate.setText(dateStr);
        Log.d(TAG, "선택된 날짜: " + dateStr);
        clearTimeSlots();
        loadSchedule(dateStr);
    }

    private void clearTimeSlots() {
        for (TextView timeSlot : timeSlots) {
            if (timeSlot != null) {
                timeSlot.setText("");
            }
        }
    }

    private void loadSchedule(String dateStr) {
        Log.d(TAG, "loadSchedule 호출됨: " + dateStr);

        db.collection("books")
                .whereEqualTo("studioId", studioId)
                .whereEqualTo("bookDate", dateStr)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();
                        Log.d(TAG, "예약 정보 불러오기 성공: " + querySnapshot.size() + "개의 문서");

                        for (DocumentSnapshot document : querySnapshot.getDocuments()) {
                            String bookedDate = document.getString("bookDate");
                            String startTime = document.getString("startTime");
                            String endTime = document.getString("endTime");

                            if (bookedDate == null || startTime == null || endTime == null) continue;

                            Log.d(TAG, "예약 날짜: " + bookedDate);

                            try {
                                // 시간을 Calendar 객체로 변환
                                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
                                Calendar startCal = Calendar.getInstance();
                                Calendar endCal = Calendar.getInstance();
                                startCal.setTime(timeFormat.parse(startTime));
                                endCal.setTime(timeFormat.parse(endTime));

                                // customerId 추출
                                String customerId = document.getString("customerId");
                                Log.d(TAG, "예약자 ID: " + customerId);

                                // 30분 간격으로 반복하여 TextView 업데이트
                                while (startCal.before(endCal)) {
                                    String timeSlot = "_"
                                            + String.format(Locale.getDefault(), "%02d", startCal.get(Calendar.HOUR_OF_DAY))
                                            + "_"
                                            + String.format(Locale.getDefault(), "%02d", startCal.get(Calendar.MINUTE));

                                    // ID로 TextView를 찾아 customerId 텍스트 설정
                                    int resId = getResources().getIdentifier(timeSlot, "id", getPackageName());
                                    if (resId != 0) {
                                        TextView timeSlotView = findViewById(resId);
                                        if (timeSlotView != null) {
                                            timeSlotView.setText(customerId);
                                            Log.d(TAG, "시간 슬롯 업데이트: " + timeSlot + " - " + customerId);
                                        }
                                    }

                                    // startCal에 30분 더하기
                                    startCal.add(Calendar.MINUTE, 30);
                                }
                            } catch (ParseException e) {
                                Log.w(TAG, "시간 파싱 오류", e);
                            }
                        }
                    } else {
                        Log.w(TAG, "문서 가져오기 오류.", task.getException());
                    }
                });
    }
}
